/* Copyright 2010 Nathan Dolan. All rights reserved. */

package com.sureassert.uc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Specifies values to be set on a field in the use case execution context,
 * before UseCases are run on the class.
 * 
 * @author Nathan Dolan
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface TestState {

	/**
	 * Defines the value to set for this field as a SIN Type.
	 */
	public String value();
}
