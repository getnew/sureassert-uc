/* Copyright 2010 Nathan Dolan. All rights reserved. */

package com.sureassert.uc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Demarks a JUnit test class for a class.
 * 
 * @author Nathan Dolan
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE })
public @interface HasJUnit {

	/**
	 * The full class name of the JUnit test class that tests this class.
	 * <p>
	 * The given JUnit test class will be executed whenever this class changes, and whenever any
	 * other source dependencies of the JUnit tests change.
	 * </p>
	 * <p>
	 * Any test errors/failures will be marked as errors at the point they failed within this class
	 * if possible.
	 * </p>
	 * 
	 */
	public String jUnitClassName();

	/**
	 * <p>
	 * Whether the JUnit tests should be executed using the master project source code or the
	 * Sureassert UC instrumented source code.
	 * </p>
	 * <p>
	 * If true (the default setting), classes will be replaced with their test doubles, stubs will
	 * be active, etc, within the context of the executed test class.
	 * </p>
	 * <p>
	 * If false, the test class will execute against the master project source and yield the same
	 * results as if executed outside the context of Sureassert UC.
	 * </p>
	 */
	public boolean useInstrumentedSource() default true;

}
