/* Copyright 2010 Nathan Dolan. All rights reserved. */

package com.sureassert.uc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Assigns a name to a class.
 * 
 * @author Nathan Dolan
 */
@Retention(RetentionPolicy.RUNTIME)
@Target( { ElementType.TYPE })
public @interface NamedClass {

	/** A name to assign to this class. */
	String name();
}
