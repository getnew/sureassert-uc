/* Copyright 2010 Nathan Dolan. All rights reserved. */

package com.sureassert.uc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Demarks a class as a test-double for a stated class.
 * 
 * @author Nathan Dolan
 */
@Retention(RetentionPolicy.RUNTIME)
@Target( { ElementType.TYPE })
public @interface TestDouble {

	/** The name of this test double. */
	public String name() default "";

	/** The class that this test double will replace. */
	public Class<?> replaces();
}
