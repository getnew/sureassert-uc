/* Copyright 2010 Nathan Dolan. All rights reserved. */

package com.sureassert.uc.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Identifies a method that should be tested and specifies test data and the
 * expected response.
 * 
 * @author Nathan Dolan
 */
@Retention(RetentionPolicy.RUNTIME)
@Target( { ElementType.METHOD, ElementType.CONSTRUCTOR })
public @interface Stubs {

	/**
	 * A list of method stub definitions.
	 * <p>
	 * Method stubs are defined as <code>signature=expression</code>, where <code>signature</code>
	 * is the signature of the method to be stubbed and expression is a SIN Expression that replaces
	 * the implementation of the stubbed method.
	 * <p>
	 * Alternatively, method stubs can be defined as <code>signature=[sl:expression]</code>, i.e. a
	 * method is assigned a &quot;stub list&quot; of expressions to be used as implementations of
	 * the stubbed method. The items in the list are iterated for each invocation of the stubbed
	 * method under the test method. Where the number of invocations exceeds the number of stub
	 * expressions in the list, the last defined stub expression is used.
	 * <p>
	 * Method <code>signature</code>s are defined as <code>class.method</code>,
	 * <code>class.method()</code> or <code>class.method(arg1class, ..., argNclass)</code> where:
	 * <li><code>class</code> is the simple or fully-qualified class name of the stubbed method.
	 * Fully-qualified names must use <code>/</code> as the package separator rather than
	 * <code>.</code>
	 * <li><code>method</code> is the name of the method to stub and
	 * <li>optionally <code>argXclass</code> is the simple or fully-qualified class name of each
	 * argument of the stubbed method. Note that methods are matched based on whether the classes of
	 * arguments passed at runtime are assignable to the specified argument classes.<br>
	 * <br>
	 * <p>
	 * If the <code>class.method</code> notation is used, the stub expression will be applied to all
	 * methods with the given name.
	 */
	String[] stubs() default {};
}
